/**
 * ============================================================================
 * College Bus Management System - Main Application Script
 * ============================================================================
 * Handles:
 * - Common sidebar navigation and active page highlighting
 * - Mobile responsive sidebar drawer
 * - Toast notification popups
 * - Modal dialog open/close helpers
 * - Form validation routines
 * - Logout / Role switcher
 */

document.addEventListener('DOMContentLoaded', () => {
  initNavigationHighlight();
  initMobileSidebar();
  initModalDismissHandlers();
});

/**
 * Automatically detects the current page filename and highlights
 * the corresponding navigation item in the sidebar menu.
 */
function initNavigationHighlight() {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const navLinks = document.querySelectorAll('aside nav a, .sidebar-nav-link');
  
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href && href === currentPath) {
      link.classList.add('bg-[#8B5CF6]', 'text-white', 'font-semibold', 'shadow-sm');
      link.classList.remove('text-[#9CA3AF]');
      link.setAttribute('aria-current', 'page');
    }
  });
}

/**
 * Adds mobile hamburger toggle behavior to open/close the navigation sidebar.
 */
function initMobileSidebar() {
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const sidebar = document.querySelector('aside');
  const backdrop = document.getElementById('sidebar-backdrop');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('sidebar-open');
      if (backdrop) {
        backdrop.classList.toggle('active');
      }
    });
  }

  if (backdrop && sidebar) {
    backdrop.addEventListener('click', () => {
      sidebar.classList.remove('sidebar-open');
      backdrop.classList.remove('active');
    });
  }
}

/**
 * Closes open modals when clicking outside or pressing Escape key.
 */
function initModalDismissHandlers() {
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const openModals = document.querySelectorAll('.app-modal:not(.hidden)');
      openModals.forEach(modal => modal.classList.add('hidden'));
    }
  });

  // Modal backdrop click
  document.querySelectorAll('.app-modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  });
}

/**
 * Open a modal by DOM element ID.
 * @param {string} modalId 
 */
function openModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) {
    el.classList.remove('hidden');
    // autofocus first input if present
    const firstInput = el.querySelector('input, select, textarea');
    if (firstInput) setTimeout(() => firstInput.focus(), 50);
  }
}

/**
 * Close a modal by DOM element ID.
 * @param {string} modalId 
 */
function closeModal(modalId) {
  const el = document.getElementById(modalId);
  if (el) {
    el.classList.add('hidden');
    // Clear validation errors inside modal if any
    el.querySelectorAll('.field-error-text').forEach(e => e.remove());
    el.querySelectorAll('.input-invalid').forEach(e => e.classList.remove('input-invalid'));
  }
}

/**
 * Toast Notification System
 * Displays a non-intrusive alert toast at the bottom right.
 * @param {string} message - Notification text
 * @param {'info'|'success'|'warning'|'error'} type - Style type
 * @param {number} durationMs - Auto close timeout in ms
 */
function showToast(message, type = 'info', durationMs = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let iconName = 'info';
  if (type === 'success') iconName = 'check_circle';
  if (type === 'warning') iconName = 'warning';
  if (type === 'error') iconName = 'error';

  toast.innerHTML = `
    <span class="material-symbols-outlined text-[20px] shrink-0 text-[#C4B5FD]">${iconName}</span>
    <div class="flex-1 text-sm font-medium leading-snug">${message}</div>
    <button class="text-[#9CA3AF] hover:text-white transition-colors" onclick="this.parentElement.remove()">
      <span class="material-symbols-outlined text-[16px]">close</span>
    </button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(40px)';
    setTimeout(() => toast.remove(), 250);
  }, durationMs);
}

/**
 * Validate a set of form inputs for required presence.
 * Shows accessible red feedback messages under invalid inputs.
 * @param {HTMLFormElement} formElement 
 * @returns {boolean} true if valid, false if invalid
 */
function validateRequiredFields(formElement) {
  let isValid = true;
  // Clear existing errors
  formElement.querySelectorAll('.field-error-text').forEach(el => el.remove());
  formElement.querySelectorAll('.input-invalid').forEach(el => el.classList.remove('input-invalid'));

  const inputs = formElement.querySelectorAll('[required]');
  inputs.forEach(input => {
    const val = input.value.trim();
    if (!val) {
      isValid = false;
      input.classList.add('input-invalid');
      
      const errorSpan = document.createElement('div');
      errorSpan.className = 'field-error-text flex items-center gap-1';
      errorSpan.innerHTML = `<span class="material-symbols-outlined text-[14px]">error</span> ${input.dataset.label || 'This field'} is required.`;
      
      input.parentElement.appendChild(errorSpan);
    }
  });

  return isValid;
}

/**
 * Logout the user and return to the main login portal.
 */
function logout() {
  localStorage.removeItem('cbms_logged_in_role');
  showToast('Signed out of campus transit console', 'info', 1500);
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 500);
}
