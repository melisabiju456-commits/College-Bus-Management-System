/**
 * ============================================================================
 * College Bus Management System - Simulated GPS & Telemetry Engine
 * ============================================================================
 * Beginner Note:
 * This script powers the interactive demonstration on:
 * - Student Dashboard (student-dashboard.html)
 * - Driver Dashboard (driver-dashboard.html)
 * - Smart Transit Intelligence & Tracking (transit-tracking.html)
 *
 * It uses predefined sample coordinates on the campus SVG map.
 * IMPORTANT: All telemetry and GPS coordinates are strictly simulated.
 */

const TransitTracker = {
  // Ordered waypoints along Route 4B (Blue Line Campus Express)
  waypoints: [
    { x: 120, y: 490, rot: 35, stopName: "1. Metro Station Junction", nextStopName: "2. Oakridge Residential", baseEta: 18, speed: 0, isMajorStop: true, stopIdx: 0 },
    { x: 170, y: 435, rot: 30, stopName: "En Route to Oakridge", nextStopName: "2. Oakridge Residential", baseEta: 15, speed: 38, isMajorStop: false },
    { x: 220, y: 380, rot: 25, stopName: "2. Oakridge Residential", nextStopName: "3. West Quad Hub", baseEta: 12, speed: 20, isMajorStop: true, stopIdx: 1 },
    { x: 295, y: 340, rot: 30, stopName: "En Route to West Quad", nextStopName: "3. West Quad Hub", baseEta: 9, speed: 42, isMajorStop: false },
    { x: 370, y: 300, rot: 35, stopName: "3. West Quad Hub", nextStopName: "4. SciTech Lab", baseEta: 6, speed: 25, isMajorStop: true, stopIdx: 2 },
    { x: 430, y: 280, rot: 45, stopName: "En Route to SciTech", nextStopName: "4. SciTech Lab", baseEta: 4, speed: 40, isMajorStop: false },
    { x: 490, y: 260, rot: 50, stopName: "4. SciTech Laboratory Complex", nextStopName: "5. Library Plaza", baseEta: 3, speed: 18, isMajorStop: true, stopIdx: 3 },
    { x: 555, y: 295, rot: 65, stopName: "En Route to Library", nextStopName: "5. Library Plaza", baseEta: 2, speed: 35, isMajorStop: false },
    { x: 620, y: 330, rot: 40, stopName: "5. University Library Plaza", nextStopName: "6. Central Terminal", baseEta: 1, speed: 22, isMajorStop: true, stopIdx: 4 },
    { x: 720, y: 385, rot: 35, stopName: "En Route to Central Terminal", nextStopName: "6. Central Terminal", baseEta: 1, speed: 32, isMajorStop: false },
    { x: 820, y: 440, rot: 40, stopName: "6. Central Terminal & Student Union", nextStopName: "Terminal Loop End", baseEta: 0, speed: 0, isMajorStop: true, stopIdx: 5 }
  ],

  currentIndex: 4, // Starts near West Quad Hub by default
  isRunning: false,
  timerId: null,
  delayMinutes: 0,
  isBrokenDown: false,
  breakdownState: null,

  /**
   * Initialize event handlers and bind to buttons on page load
   */
  init: function() {
    this.updateUI();

    // Start Tracking
    const startBtns = document.querySelectorAll('#btn-start-tracking, .btn-start-tracking');
    startBtns.forEach(btn => btn.addEventListener('click', () => this.start()));

    // Pause Tracking
    const pauseBtns = document.querySelectorAll('#btn-pause-tracking, .btn-pause-tracking');
    pauseBtns.forEach(btn => btn.addEventListener('click', () => this.pause()));

    // Move to Next Stop
    const nextBtns = document.querySelectorAll('#btn-next-stop, #stepSimBtn, .btn-next-stop');
    nextBtns.forEach(btn => btn.addEventListener('click', () => this.nextStop()));

    // Demo Delay Trigger
    const delayBtns = document.querySelectorAll('#btn-demo-delay, #btn-open-delay-modal, .btn-demo-delay');
    delayBtns.forEach(btn => btn.addEventListener('click', () => this.triggerDelay(8)));

    // Demo Breakdown Trigger
    const breakdownBtns = document.querySelectorAll('#btn-demo-breakdown, #btn-open-breakdown-modal, .btn-demo-breakdown');
    breakdownBtns.forEach(btn => btn.addEventListener('click', () => this.triggerBreakdown()));

    // Reset Breakdown Button
    const resetBreakdownBtns = document.querySelectorAll('#btn-reset-breakdown, .btn-reset-breakdown');
    resetBreakdownBtns.forEach(btn => btn.addEventListener('click', () => this.resetBreakdown()));

    // Map controls (zoom & recenter)
    this.initMapControls();
  },

  /**
   * Start simulated telemetry movement
   */
  start: function() {
    if (this.isBrokenDown) {
      if (typeof showToast === 'function') {
        showToast('Cannot start tracking: Bus is in breakdown status. Reset breakdown first.', 'error');
      }
      return;
    }

    if (this.isRunning) return;
    this.isRunning = true;

    if (typeof showToast === 'function') {
      showToast('Simulated GPS telemetry started: Bus marker is moving.', 'success');
    }

    this.timerId = setInterval(() => {
      this.stepForward();
    }, 2800);

    this.updateControlsUI();
  },

  /**
   * Pause simulated tracking
   */
  pause: function() {
    if (!this.isRunning) return;
    this.isRunning = false;
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }

    if (typeof showToast === 'function') {
      showToast('Tracking paused: Bus marker held at current simulated coordinate.', 'info');
    }

    this.updateControlsUI();
  },

  /**
   * Advance one waypoint forward along the route
   */
  stepForward: function() {
    this.currentIndex = (this.currentIndex + 1) % this.waypoints.length;
    this.updateUI();
  },

  /**
   * Jump directly to the next major stop
   */
  nextStop: function() {
    if (this.isBrokenDown) {
      if (typeof showToast === 'function') {
        showToast('Bus is currently stalled in breakdown simulation mode.', 'warning');
      }
      return;
    }

    let foundNext = false;
    for (let i = this.currentIndex + 1; i < this.waypoints.length; i++) {
      if (this.waypoints[i].isMajorStop) {
        this.currentIndex = i;
        foundNext = true;
        break;
      }
    }
    // If not found ahead, wrap around to first stop
    if (!foundNext) {
      this.currentIndex = 0;
    }

    this.updateUI();

    if (typeof showToast === 'function') {
      const cur = this.waypoints[this.currentIndex];
      showToast(`Bus arrived at: ${cur.stopName}`, 'info');
    }
  },

  /**
   * Trigger a demo delay simulation
   * @param {number} addedMins 
   */
  triggerDelay: function(addedMins = 8) {
    this.delayMinutes += addedMins;
    this.updateUI();

    const delayBanner = document.getElementById('delay-alert-banner');
    if (delayBanner) {
      delayBanner.classList.remove('hidden');
      const textEl = delayBanner.querySelector('.delay-text');
      if (textEl) {
        textEl.textContent = `Transit Advisory: Moderate campus traffic near Quad. Added delay: +${this.delayMinutes} mins.`;
      }
    }

    if (typeof showToast === 'function') {
      showToast(`Advisory logged: Route 4B delayed by +${this.delayMinutes} minutes due to traffic.`, 'warning');
    }
  },

  /**
   * Trigger a demo bus breakdown simulation with alternative relief recommendation
   */
  triggerBreakdown: function() {
    this.pause();
    this.isBrokenDown = true;
    
    // Save to DataStore
    if (typeof DataStore !== 'undefined') {
      this.breakdownState = DataStore.triggerBreakdownDemo();
    }

    this.updateUI();

    // Show Emergency Modal or Banner
    const breakdownModal = document.getElementById('breakdown-alert-modal');
    if (breakdownModal) {
      breakdownModal.classList.remove('hidden');
    }

    const breakdownBanner = document.getElementById('breakdown-alert-banner');
    if (breakdownBanner) {
      breakdownBanner.classList.remove('hidden');
    }

    if (typeof showToast === 'function') {
      showToast('EMERGENCY SIMULATION TRIGGERED: Bus #19 coolant breakdown reported!', 'error', 5000);
    }
  },

  /**
   * Dismiss/reset the breakdown alert back to nominal state
   */
  resetBreakdown: function() {
    this.isBrokenDown = false;
    this.delayMinutes = 0;

    if (typeof DataStore !== 'undefined') {
      DataStore.resetEmergencyDemo();
    }

    const breakdownModal = document.getElementById('breakdown-alert-modal');
    if (breakdownModal) breakdownModal.classList.add('hidden');

    const breakdownBanner = document.getElementById('breakdown-alert-banner');
    if (breakdownBanner) breakdownBanner.classList.add('hidden');

    const delayBanner = document.getElementById('delay-alert-banner');
    if (delayBanner) delayBanner.classList.add('hidden');

    this.updateUI();

    if (typeof showToast === 'function') {
      showToast('Emergency simulation reset: All systems nominal.', 'success');
    }
  },

  /**
   * Update all DOM elements reflecting vehicle state, marker, and metrics
   */
  updateUI: function() {
    const cur = this.waypoints[this.currentIndex];
    const totalEta = Math.max(0, cur.baseEta + this.delayMinutes);

    // 1. Update SVG marker position if present
    const vehicleGroup = document.getElementById('vehicleIconGroup');
    if (vehicleGroup) {
      vehicleGroup.setAttribute('transform', `translate(${cur.x}, ${cur.y}) rotate(${cur.rot})`);
    }

    // 2. Stop names
    const curStopEls = document.querySelectorAll('.val-current-stop');
    curStopEls.forEach(el => el.textContent = cur.stopName);

    const nextStopEls = document.querySelectorAll('.val-next-stop');
    nextStopEls.forEach(el => el.textContent = cur.nextStopName);

    // 3. ETA
    const etaEls = document.querySelectorAll('.val-eta, #etaDisplay');
    etaEls.forEach(el => {
      el.textContent = this.isBrokenDown ? 'DELAYED (HOLD)' : `${totalEta} mins`;
    });

    // 4. Speed
    const speedEls = document.querySelectorAll('.val-speed, #speedDisplay');
    speedEls.forEach(el => {
      const spd = this.isBrokenDown ? 0 : cur.speed;
      el.innerHTML = `${spd} <span class="text-xs text-[#C4B5FD] font-normal">km/h</span>`;
    });

    // 5. Route Progress
    const progressPercent = Math.round(((this.currentIndex + 1) / this.waypoints.length) * 100);
    const progressBars = document.querySelectorAll('.val-route-progress-bar');
    progressBars.forEach(bar => {
      bar.style.width = `${progressPercent}%`;
    });
    const progressLabels = document.querySelectorAll('.val-route-progress-text');
    progressLabels.forEach(txt => {
      txt.textContent = `${progressPercent}% completed`;
    });

    // 6. Status Badge
    const statusBadges = document.querySelectorAll('.val-bus-status');
    statusBadges.forEach(badge => {
      if (this.isBrokenDown) {
        badge.textContent = 'CRITICAL BREAKDOWN';
        badge.className = 'val-bus-status px-2.5 py-0.5 rounded-full bg-red-950/80 text-red-300 border border-red-700 text-xs font-bold';
      } else if (this.delayMinutes > 0) {
        badge.textContent = `DELAYED (+${this.delayMinutes}m)`;
        badge.className = 'val-bus-status px-2.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-600 text-xs font-bold';
      } else if (this.isRunning) {
        badge.textContent = 'ON TIME • IN TRANSIT';
        badge.className = 'val-bus-status px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-600 text-xs font-bold';
      } else {
        badge.textContent = 'STANDBY / IDLE';
        badge.className = 'val-bus-status px-2.5 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700 text-xs font-bold';
      }
    });

    this.updateControlsUI();
  },

  /**
   * Update Start / Pause button visual indicators
   */
  updateControlsUI: function() {
    const startBtns = document.querySelectorAll('#btn-start-tracking, .btn-start-tracking');
    const pauseBtns = document.querySelectorAll('#btn-pause-tracking, .btn-pause-tracking');

    startBtns.forEach(btn => {
      if (this.isRunning) {
        btn.classList.add('ring-2', 'ring-white', 'opacity-90');
      } else {
        btn.classList.remove('ring-2', 'ring-white', 'opacity-90');
      }
    });

    pauseBtns.forEach(btn => {
      if (!this.isRunning && !this.isBrokenDown) {
        btn.classList.add('border-[#8B5CF6]');
      } else {
        btn.classList.remove('border-[#8B5CF6]');
      }
    });
  },

  /**
   * Simulated Map Zoom & Recenter controls
   */
  initMapControls: function() {
    const mapSvg = document.getElementById('transitSvgMap');
    const recenterBtn = document.getElementById('recenterBtn');
    const zoomInBtn = document.getElementById('zoomInBtn');
    const zoomOutBtn = document.getElementById('zoomOutBtn');
    const layerToggleBtn = document.getElementById('layerToggleBtn');

    let scale = 1;
    let isDarkAlt = false;

    if (recenterBtn && mapSvg) {
      recenterBtn.addEventListener('click', () => {
        scale = 1.15;
        mapSvg.style.transform = `scale(${scale}) translate(-20px, -10px)`;
        setTimeout(() => {
          mapSvg.style.transform = `scale(1) translate(0px, 0px)`;
          scale = 1;
        }, 800);
        if (typeof showToast === 'function') {
          showToast('Map recentered on Bus #08 simulated location.', 'info', 1800);
        }
      });
    }

    if (zoomInBtn && mapSvg) {
      zoomInBtn.addEventListener('click', () => {
        if (scale < 1.6) {
          scale += 0.15;
          mapSvg.style.transform = `scale(${scale})`;
        }
      });
    }

    if (zoomOutBtn && mapSvg) {
      zoomOutBtn.addEventListener('click', () => {
        if (scale > 0.8) {
          scale -= 0.15;
          mapSvg.style.transform = `scale(${scale})`;
        }
      });
    }

    if (layerToggleBtn && mapSvg) {
      layerToggleBtn.addEventListener('click', () => {
        isDarkAlt = !isDarkAlt;
        const baseRect = mapSvg.querySelector('rect');
        if (baseRect) {
          baseRect.setAttribute('fill', isDarkAlt ? '#0b0b0e' : '#141416');
        }
        if (typeof showToast === 'function') {
          showToast(isDarkAlt ? 'Layer: Deep Night Canvas' : 'Layer: Standard Campus Blueprint', 'info', 1500);
        }
      });
    }
  }
};

// Initialize if DOM is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => TransitTracker.init());
} else {
  TransitTracker.init();
}
