/**
 * ============================================================================
 * College Bus Management System - Data Store & LocalStorage Manager
 * ============================================================================
 * Beginner Note:
 * This script provides fictional sample data for demonstration purposes.
 * It uses the browser's localStorage to persist changes (like adding or deleting
 * a bus, student, or driver) during the frontend demo phase.
 * In a future phase, this will connect to Java, JDBC, and MySQL.
 */

const DEFAULT_BUSES = [
  {
    id: "BUS-108",
    number: "Bus #08",
    registration: "DL-1PC-4820",
    model: "Volvo B7R Low Floor",
    route: "Route 4B — Science Quad Express",
    driver: "Marcus Vance",
    capacity: 45,
    occupied: 38,
    status: "Active",
    speed: "34 km/h",
    lastService: "2026-09-12"
  },
  {
    id: "BUS-114",
    number: "Bus #14",
    registration: "DL-1PC-3319",
    model: "Scania Citywide 12M",
    route: "Route 1A — South Campus Loop",
    driver: "David Miller",
    capacity: 52,
    occupied: 46,
    status: "Active",
    speed: "28 km/h",
    lastService: "2026-08-30"
  },
  {
    id: "BUS-119",
    number: "Bus #19",
    registration: "DL-1PC-9204",
    model: "Tata Starbus Ultra",
    route: "Route 2C — East Quad Shuttle",
    driver: "Sarah Jenkins",
    capacity: 40,
    occupied: 22,
    status: "Maintenance",
    speed: "0 km/h (Stalled)",
    lastService: "2026-06-15"
  },
  {
    id: "BUS-122",
    number: "Bus #22",
    registration: "DL-1PC-7781",
    model: "Volvo B8R High-Capacity",
    route: "Campus Depot Standby Pool",
    driver: "Robert Evans",
    capacity: 50,
    occupied: 0,
    status: "Standby",
    speed: "0 km/h (Ready)",
    lastService: "2026-10-01"
  },
  {
    id: "BUS-103",
    number: "Bus #03",
    registration: "DL-1PC-1102",
    model: "Ashok Leyland Falcon",
    route: "Route 8 — North Gate Commuter",
    driver: "James Wilson",
    capacity: 45,
    occupied: 41,
    status: "Active",
    speed: "32 km/h",
    lastService: "2026-09-22"
  },
  {
    id: "BUS-111",
    number: "Bus #11",
    registration: "DL-1PC-5541",
    model: "Scania Citywide 12M",
    route: "Route 3B — West Gate Express",
    driver: "Emily Chen",
    capacity: 48,
    occupied: 35,
    status: "Active",
    speed: "30 km/h",
    lastService: "2026-07-18"
  }
];

const DEFAULT_STUDENTS = [
  {
    id: "STU-8842",
    name: "Alex Chen",
    department: "Computer Science & Eng",
    semester: "4th Semester",
    email: "alex.chen@campus.edu",
    phone: "555-0182",
    busNumber: "Bus #08",
    route: "Route 4B — Science Quad Express",
    stop: "West Quad Hub",
    status: "Verified Active"
  },
  {
    id: "STU-8843",
    name: "Priya Patel",
    department: "Electronics & Communication",
    semester: "6th Semester",
    email: "priya.p@campus.edu",
    phone: "555-0193",
    busNumber: "Bus #08",
    route: "Route 4B — Science Quad Express",
    stop: "Oakridge Residential",
    status: "Verified Active"
  },
  {
    id: "STU-8844",
    name: "Jordan Smith",
    department: "Mechanical Engineering",
    semester: "2nd Semester",
    email: "j.smith@campus.edu",
    phone: "555-0144",
    busNumber: "Bus #14",
    route: "Route 1A — South Campus Loop",
    stop: "South Gate Roundabout",
    status: "Verified Active"
  },
  {
    id: "STU-8845",
    name: "Sofia Rodriguez",
    department: "Biotechnology",
    semester: "8th Semester",
    email: "s.rodriguez@campus.edu",
    phone: "555-0125",
    busNumber: "Bus #03",
    route: "Route 8 — North Gate Commuter",
    stop: "North Gate Entrance",
    status: "Verified Active"
  },
  {
    id: "STU-8846",
    name: "Michael Chang",
    department: "Business Analytics",
    semester: "4th Semester",
    email: "m.chang@campus.edu",
    phone: "555-0136",
    busNumber: "Bus #11",
    route: "Route 3B — West Gate Express",
    stop: "West Terminal Hub",
    status: "Pending Review"
  },
  {
    id: "STU-8847",
    name: "Ananya Sharma",
    department: "Information Technology",
    semester: "6th Semester",
    email: "ananya.s@campus.edu",
    phone: "555-0198",
    busNumber: "Bus #19",
    route: "Route 2C — East Quad Shuttle",
    stop: "East Dormitories",
    status: "Verified Active"
  }
];

const DEFAULT_DRIVERS = [
  {
    id: "DRV-104",
    name: "Marcus Vance",
    phone: "555-0143",
    email: "m.vance@transit.campus.edu",
    busNumber: "Bus #08",
    route: "Route 4B — Science Quad Express",
    license: "CDL Class-B (Heavy Passenger)",
    expiry: "2027-08-15",
    shift: "Morning Peak (06:30 - 14:30)",
    status: "On Shift"
  },
  {
    id: "DRV-108",
    name: "David Miller",
    phone: "555-0167",
    email: "d.miller@transit.campus.edu",
    busNumber: "Bus #14",
    route: "Route 1A — South Campus Loop",
    license: "CDL Class-B (Heavy Passenger)",
    expiry: "2027-11-20",
    shift: "Morning Peak (07:00 - 15:00)",
    status: "On Shift"
  },
  {
    id: "DRV-115",
    name: "Robert Evans",
    phone: "555-0189",
    email: "r.evans@transit.campus.edu",
    busNumber: "Standby Bus #22",
    route: "Campus Depot Standby Pool",
    license: "CDL Class-A (Commercial Master)",
    expiry: "2026-11-30",
    shift: "Emergency Relief Standby",
    status: "Standby"
  },
  {
    id: "DRV-122",
    name: "Sarah Jenkins",
    phone: "555-0191",
    email: "s.jenkins@transit.campus.edu",
    busNumber: "Bus #19",
    route: "Route 2C — East Quad Shuttle",
    license: "CDL Class-B (Heavy Passenger)",
    expiry: "2028-03-12",
    shift: "Afternoon Relief",
    status: "Maintenance Hold"
  },
  {
    id: "DRV-128",
    name: "James Wilson",
    phone: "555-0175",
    email: "j.wilson@transit.campus.edu",
    busNumber: "Bus #03",
    route: "Route 8 — North Gate Commuter",
    license: "CDL Class-B (Heavy Passenger)",
    expiry: "2026-12-05",
    shift: "Morning Peak (06:30 - 14:30)",
    status: "On Shift"
  }
];

const ROUTE_4B_STOPS = [
  { id: 1, name: "1. Metro Station Junction", time: "08:10 AM", etaMinutes: 0, x: 120, y: 490, rot: 35 },
  { id: 2, name: "2. Oakridge Residential", time: "08:22 AM", etaMinutes: 3, x: 220, y: 380, rot: 25 },
  { id: 3, name: "3. West Quad Hub", time: "08:35 AM", etaMinutes: 6, x: 370, y: 300, rot: 35 },
  { id: 4, name: "4. SciTech Laboratory Complex", time: "08:44 AM", etaMinutes: 10, x: 490, y: 260, rot: 50 },
  { id: 5, name: "5. University Library Plaza", time: "08:52 AM", etaMinutes: 15, x: 620, y: 330, rot: 65 },
  { id: 6, name: "6. Central Terminal & Student Union", time: "09:00 AM", etaMinutes: 20, x: 820, y: 440, rot: 40 }
];

// Data Store Object
const DataStore = {
  // --- Buses ---
  getBuses: function() {
    const raw = localStorage.getItem('cbms_buses');
    if (!raw) {
      this.saveBuses(DEFAULT_BUSES);
      return [...DEFAULT_BUSES];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [...DEFAULT_BUSES];
    }
  },
  saveBuses: function(buses) {
    localStorage.setItem('cbms_buses', JSON.stringify(buses));
  },
  addBus: function(bus) {
    const buses = this.getBuses();
    buses.unshift(bus);
    this.saveBuses(buses);
    return buses;
  },
  deleteBus: function(busId) {
    const buses = this.getBuses().filter(b => b.id !== busId);
    this.saveBuses(buses);
    return buses;
  },
  updateBus: function(updatedBus) {
    const buses = this.getBuses().map(b => b.id === updatedBus.id ? updatedBus : b);
    this.saveBuses(buses);
    return buses;
  },

  // --- Students ---
  getStudents: function() {
    const raw = localStorage.getItem('cbms_students');
    if (!raw) {
      this.saveStudents(DEFAULT_STUDENTS);
      return [...DEFAULT_STUDENTS];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [...DEFAULT_STUDENTS];
    }
  },
  saveStudents: function(students) {
    localStorage.setItem('cbms_students', JSON.stringify(students));
  },
  addStudent: function(student) {
    const students = this.getStudents();
    students.unshift(student);
    this.saveStudents(students);
    return students;
  },
  deleteStudent: function(studentId) {
    const students = this.getStudents().filter(s => s.id !== studentId);
    this.saveStudents(students);
    return students;
  },

  // --- Drivers ---
  getDrivers: function() {
    const raw = localStorage.getItem('cbms_drivers');
    if (!raw) {
      this.saveDrivers(DEFAULT_DRIVERS);
      return [...DEFAULT_DRIVERS];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [...DEFAULT_DRIVERS];
    }
  },
  saveDrivers: function(drivers) {
    localStorage.setItem('cbms_drivers', JSON.stringify(drivers));
  },
  addDriver: function(driver) {
    const drivers = this.getDrivers();
    drivers.unshift(driver);
    this.saveDrivers(drivers);
    return drivers;
  },
  deleteDriver: function(driverId) {
    const drivers = this.getDrivers().filter(d => d.id !== driverId);
    this.saveDrivers(drivers);
    return drivers;
  },
  updateDriver: function(updatedDriver) {
    const drivers = this.getDrivers().map(d => d.id === updatedDriver.id ? updatedDriver : d);
    this.saveDrivers(drivers);
    return drivers;
  },

  // --- Active Emergency Simulation State ---
  getEmergencyState: function() {
    const raw = localStorage.getItem('cbms_emergency_state');
    if (!raw) {
      // Default: breakdown on Bus #19
      const state = {
        active: false,
        busNumber: "Bus #19",
        busId: "BUS-119",
        route: "Route 2C — East Quad Shuttle",
        driver: "Sarah Jenkins",
        location: "South Gate Roundabout near Dormitory Complex",
        issue: "Engine Overheating & Coolant Leak",
        strandedStudents: 22,
        recommendedBus: "Standby Bus #22",
        recommendedDriver: "Robert Evans",
        recommendedCapacity: 50,
        deployed: false
      };
      return state;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return { active: false };
    }
  },
  saveEmergencyState: function(state) {
    localStorage.setItem('cbms_emergency_state', JSON.stringify(state));
  },
  triggerBreakdownDemo: function() {
    const state = {
      active: true,
      busNumber: "Bus #19",
      busId: "BUS-119",
      route: "Route 2C — East Quad Shuttle",
      driver: "Sarah Jenkins",
      location: "South Gate Roundabout near Dormitory Complex",
      issue: "Engine Overheating & Coolant Leak",
      strandedStudents: 22,
      recommendedBus: "Standby Bus #22",
      recommendedDriver: "Robert Evans",
      recommendedCapacity: 50,
      deployed: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    this.saveEmergencyState(state);
    return state;
  },
  resetEmergencyDemo: function() {
    const state = { active: false };
    this.saveEmergencyState(state);
    return state;
  },
  deployReliefBus: function() {
    const state = this.getEmergencyState();
    state.deployed = true;
    this.saveEmergencyState(state);
    return state;
  }
};

// Initialize on page load
DataStore.getBuses();
DataStore.getStudents();
DataStore.getDrivers();
