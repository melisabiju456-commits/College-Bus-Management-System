---
name: Obsidian Transit
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#ccbeff'
  on-secondary: '#332664'
  secondary-container: '#4a3d7c'
  on-secondary-container: '#baabf3'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#e7deff'
  secondary-fixed-dim: '#ccbeff'
  on-secondary-fixed: '#1e0e4e'
  on-secondary-fixed-variant: '#4a3d7c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '800'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a high-precision, tactical dark interface engineered for campus transit coordination, real-time vehicle telematics, and student mobility logistics. It balances rapid cognitive scanning with a high-tech civic aesthetic—delivering vital operational status instantly without visual fatigue during early dawn or late-night transit hours.

### Design Movement & Aesthetic
The style is **Precision Functional Dark**:
- **Tactical Clarity:** Deep pitch canvas surfaces paired with deliberate luminescent purple and status-driven signaling vectors.
- **Controlled Luminescence:** Restrained use of electric purple for primary operational triggers, balanced by frosted charcoal planes and low-attenuation borders to delineate dense schedule grids and transit maps.
- **High-Velocity Contrast:** Absolute legible hierarchy between live vehicle states, arrival countdowns, and structural route metadata.

## Colors

The palette leverages an ultra-deep canvas to minimize display power draw and eye strain while maximizing signal salience through calibrated optical contrast.

### Palette Architecture
- **Base Canvas (`#121212`):** Primary background substrate across all viewport frames.
- **Surfaces & Panels (`#1E1E1E`):** Distinct structural card and sheet containers, elevated through boundary borders rather than drop shadows.
- **Borders & Dividers (`#2D2D2D` / `#374151`):** Structural gridlines, subtle edge definition, and table division lines.
- **Electric Accent (`#8B5CF6` / `#7C3AED`):** Primary navigational actions, active bus route markers, active tabs, and critical CTA paths.
- **Soft Lavender (`#C4B5FD` / `#DDD6FE`):** Secondary chips, route category pills, minor state indicators, and active icon glyphs.
- **Text Tiers:** Absolute White (`#FFFFFF`) for primary headings, metric values, and high-priority labels; Cool Slate Muted (`#9CA3AF`) for schedule captions, route details, and inactive states.
- **Telemetry Indicators:**
  - *On-Time / Active:* Subtle Emerald (`#10B981`)
  - *Delayed / Congested:* Amber (`#F59E0B`)
  - *Out of Service / Alert:* Signal Rose (`#EF4444`)

## Typography

Plus Jakarta Sans provides high geometric legibility across all scales, optimized for rapid scanning of route numbers, arrival times, and dispatch alerts.

### Typographic Rules
- **Numerical Prominence:** Estimated time of arrivals (ETAs), vehicle numbers, and seat capacities utilize `headline-lg` or `headline-md` with `fontWeight: 700` for swift comprehension at a glance.
- **Hierarchy Separation:** Section labels, operational tags, and data grid headers must always use uppercase styling on `label-sm` or `label-md` with tracked letter-spacing (`0.02em` to `0.05em`) in `#9CA3AF`.
- **Text Truncation:** Stop names and transit alerts prioritize multi-line wrapping in cards, capping strictly at two lines for `body-md` before adding an ellipsis.

## Layout & Spacing

The layout model is anchored on an 8-point spatial cadence, transitioning dynamically across breakpoints to support both dense desktop fleet management and ergonomic single-handed mobile navigation.

### Breakpoints & Grid Model
- **Mobile (< 768px):** 4-column fluid layout. Canvas outer margin is `margin` (`1rem`), column gutters are `gutter` (`1rem`). Route cards span all 4 columns. Bottom navigation bar and expandable drawer sheets anchor transit map interactions.
- **Tablet (768px - 1024px):** 8-column layout. Canvas margins expand to `margin-md` (`1.5rem`), column gutters scale to `gutter-md` (`1.5rem`). Split-view UI with route listings spanning 3 columns and interactive map view spanning 5 columns.
- **Desktop (> 1024px):** 12-column fixed/fluid composite. Outer margins set to `margin-lg` (`2.5rem`), gutters at `gutter-lg` (`2rem`). Tri-pane architecture: Collapsed Navigation Rail (1 col), Route & Fleet Roster (4 cols), Real-time Geofence Map / Live Telemetry Matrix (7 cols).

## Elevation & Depth

In this dark-mode architecture, elevation is established using surface color luminance and low-contrast perimeter framing rather than heavy drop shadows, avoiding muddy blurs on deep black backgrounds.

### Elevation Hierarchy
- **Level 0 (Base Substrate):** Canvas fill `#121212`. The bottommost plane hosting map canvases and structural application background.
- **Level 1 (Card & Module Layer):** `#1E1E1E` surface with a continuous `1px` border of `#2D2D2D`. Used for schedule panels, route rows, and setting modules.
- **Level 2 (Floating & Interactive Panels):** `#242424` surface with a `1px` border of `#374151`. Supported by a subtle ambient tinted shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.6), 0 2px 6px -1px rgba(139, 92, 246, 0.08)`. Used for real-time stop sheets, route selection popovers, and filter toolbars.
- **Level 3 (Modals & Emergency Overlays):** `#2A2A2A` surface with an elevated `1px` border of `#4B5563` and an expanded shadow: `0 20px 32px -8px rgba(0, 0, 0, 0.85)`. Used for driver incident reports and vehicle tracking overlays.

## Shapes

The geometric vocabulary balances clean modern software conventions with friendly, approachable navigation nodes. A default roundedness tier of `2` (`0.5rem` / `8px`) preserves structural efficiency across complex schedule data.

### Corner Radius Standards
- **Interactive Controls (Inputs, Buttons, Segmented Selectors):** Base `0.5rem` (`roundedness: 2`).
- **Containers & Route Panels:** `rounded-lg` (`1rem` / `16px`) to group multiple data points clearly against the `#121212` background.
- **Floating Modals & Bottom Sheets:** `rounded-xl` (`1.5rem` / `24px`) along top leading edges for tactile mobile sheet interactions.
- **Status Tags, Metric Chips & Badges:** Full pill-shaped radius (`9999px`) to distinguish categorical metadata from rectangular interactive cards.

## Components

### Buttons
- **Primary Action (Book Ride, Track Vehicle):** Filled `#8B5CF6`, text `#FFFFFF`, label weight `600`. Hover state transitions to `#7C3AED`. Focus rings emit a `2px` offset outline of `#C4B5FD`.
- **Secondary Action (Change Route, Schedule View):** Transparent surface with a `1px` border of `#374151`, text `#FFFFFF`. Hover state adopts `#1E1E1E` background with a border of `#C4B5FD`.
- **Ghost/Tertiary:** No border, text `#9CA3AF`. Hover shifts to `#FFFFFF` with `#1E1E1E` backplate.

### Badges & Chips
- **Status Badges (Pill Shape):**
  - *Active/On-Time:* Background `rgba(16, 185, 129, 0.12)`, text `#10B981`, border `1px solid rgba(16, 185, 129, 0.25)`.
  - *Delayed:* Background `rgba(245, 158, 11, 0.12)`, text `#F59E0B`, border `1px solid rgba(245, 158, 11, 0.25)`.
  - *Alert/Breakdown:* Background `rgba(239, 68, 68, 0.12)`, text `#EF4444`, border `1px solid rgba(239, 68, 68, 0.25)`.
- **Category Filter Chips:** Interactive pills. Inactive: `#1E1E1E` with `#2D2D2D` border, text `#9CA3AF`. Active: Background `rgba(139, 92, 246, 0.15)`, text `#C4B5FD`, border `1px solid #8B5CF6`.

### Cards & Panels
- **Route Cards:** Surface `#1E1E1E`, `1px` border `#2D2D2D`, radius `1rem`. Internal vertical sequence: route indicator pill top-left, arrival countdown in `headline-md` (`#FFFFFF`) top-right, station path in `body-sm` (`#9CA3AF`) at the center, occupancy meter at bottom.
- **Live Telemetry Banner:** `#1E1E1E` surface accented by a vertical `3px` primary indicator strip along the left boundary (`#8B5CF6`).

### Input Fields
- **Search & Stop Selectors:** Height `44px`, background `#181818`, border `1px solid #2D2D2D`, text `#FFFFFF`, placeholder `#9CA3AF`. Radius `0.5rem`.
- **Focused State:** Border transitions to `#8B5CF6` with a soft glow `0 0 0 3px rgba(139, 92, 246, 0.2)`.

### Lists & Data Grids
- **Stop Sequence Lists:** Connected via a vertical dashed connector line (`#2D2D2D`). Current vehicle position indicated by an active glowing node (`#8B5CF6` ring containing `#FFFFFF` dot). Passed stops dim to `#9CA3AF` text opacity.
- **Roster Dividers:** Horizontal line `#2D2D2D`, `1px` solid, without margin collapse.

### Checkboxes & Toggle Switches
- **Checkboxes:** Base `18px x 18px`, radius `4px`, background `#121212`, border `1.5px solid #374151`. Checked state: background `#8B5CF6` with checkmark icon in `#FFFFFF`.
- **Toggle Switches (Live Alerts, Night Mode lock):** Track width `40px`, height `22px`, background `#2D2D2D`. Active track: `#8B5CF6`. Thumb: `#FFFFFF` smooth slide animation.