# 🚌 College Bus Management System (UniTransit)

> **Frontend Demonstration Phase**  
> Built using the **Obsidian Transit** Dark & Purple Design System inspired by Google Stitch UI.

---

## 📌 Project Overview

The **College Bus Management System** is a responsive, web-based campus transit portal designed for colleges and universities. It provides role-tailored dashboards for **Administrators**, **Students**, and **Drivers**, alongside fleet management, student/driver directories, simulated live GPS tracking, and emergency alternative bus dispatch.

> **Important Beginner Note:**  
> This first phase is a **frontend demonstration prototype** using HTML5, modern CSS, and vanilla JavaScript. All vehicle telemetry, GPS coordinates, passenger loads, and user records are **simulated sample data** stored in browser memory (`localStorage`). No external database or server setup is required to run and test it. Database integration (Java, JDBC, MySQL) will be added in Phase 2.

---

## 📂 Project Structure

```
stitch_college_bus_management_system/
│
├── index.html                   # 1. Main Login Portal & Role Switcher
├── admin-dashboard.html         # 2. Fleet Admin Operations Center
├── student-dashboard.html       # 3. Student Commuter Transit Hub
├── driver-dashboard.html        # 4. Driver In-Cab Console
├── bus-management.html          # 5. Bus Fleet & Asset Management
├── student-management.html      # 6. Student Commuter Directory
├── driver-management.html       # 7. Driver Staff Records & Rosters
├── transit-tracking.html        # 8. Smart Transit Intelligence & Tracking
├── emergency-management.html    # 9. Emergency Dispatch & Alternative Fleet
│
├── css/
│   └── style.css                # Obsidian Transit theme styles & animations
│
├── js/
│   ├── app.js                   # Navigation, modals, toasts & form validation
│   ├── data.js                  # Sample data store & localStorage manager
│   └── tracking.js              # Simulated GPS telemetry & waypoint engine
│
├── obsidian_transit/
│   └── DESIGN.md                # Stitch UI color tokens & design guidelines
│
└── 1._... to 9._.../            # Original Stitch reference screens & assets
```

---

## 🚀 How to Run the Website on Your Laptop

You **do not need to install complex software** to run this project. Follow any of these easy methods:

### Method 1: Direct Double-Click (Easiest — No Setup Needed)
1. Open File Explorer and navigate to the project folder:
   `Downloads\stitch_college_bus_management_system(1)\stitch_college_bus_management_system`
2. Find `index.html`.
3. **Double-click `index.html`** (or right-click → **Open with** → **Google Chrome** or **Microsoft Edge**).
4. The login portal will open directly in your web browser!

### Method 2: Using VS Code Live Server (Recommended for Presentations)
1. Open the project folder in **Visual Studio Code**.
2. Install the **Live Server** extension (by Ritwick Dey) from the Extensions tab (`Ctrl+Shift+X`).
3. Right-click on `index.html` in the file explorer and click **"Open with Live Server"**.
4. Your browser will automatically open `http://127.0.0.1:5500/index.html`.

### Method 3: Using Python (If installed)
1. Open PowerShell or Command Prompt in the project folder.
2. Run:
   ```bash
   python -m http.server 8000
   ```
3. Open your browser and navigate to `http://localhost:8000`.

---

## 🎯 College Presentation & Demo Walkthrough

When presenting this project to your college professor or examiner, follow this recommended walkthrough:

### Step 1: Login Portal (`index.html`)
- Explain the role-based design supporting **Fleet Operations (Admin)**, **Students**, and **Drivers**.
- Click the role switch tabs to demonstrate how credentials and session badges dynamically adapt.
- Clear a field and click **"Sign In"** to show required-field validation.
- Click **"Sign In to Fleet Ops Console"** to transition to the Admin Dashboard.

### Step 2: Admin Operations Center (`admin-dashboard.html`)
- Point out the KPI counters: **Total Fleet Buses (28)**, **Enrolled Students (1,842)**, **Active Drivers (32)**, and **Active Routes (14)**.
- Showcase the fleet health breakdown: Active on-time (21), Delayed (3), and Breakdown (1).
- Show the interactive campus geo-feed with filter pills (`All Buses`, `Delayed Only`, `Standby`).
- Click any bus pin (e.g., Bus #04 or Bus #07) to display the live telemetry diagnostic modal.

### Step 3: Bus Fleet Management (`bus-management.html`)
- Demonstrate searching the fleet by typing `Volvo`, `Route 4B`, or `Active` into the search bar.
- Click **"+ Add New Vehicle"** to show the modal form with validation. Add a demo bus and observe it appearing in the table immediately.
- Explain that data persists using browser `localStorage` in Phase 1 before MySQL is connected in Phase 2.

### Step 4: Student & Driver Directories (`student-management.html` & `driver-management.html`)
- Show search and filter capabilities for students by department, bus, or stop.
- Show driver records with commercial licenses, shifts, and direct radio channels.

### Step 5: Student Transit Hub (`student-dashboard.html`)
- Point out the fictional student profile for Alex Chen assigned to Bus #08.
- Click **"Start Tracking"** to watch the simulated bus marker move along Route 4B across campus waypoints.
- Notice how the **Current Stop**, **Next Stop**, and **ETA** continuously update as the bus travels.
- Click **"+8m Delay Demo"** to simulate traffic congestion — an amber warning banner appears, and the ETA increases by 8 minutes.
- Click **"Simulate Breakdown"** — a critical emergency banner appears indicating Bus #19 has broken down, and Standby Bus #22 is immediately recommended.
- Click **"Reset Breakdown Demo"** to restore normal service.
- Highlight the **"SIMULATED GPS — DEMO MODE"** safety label.

### Step 6: Driver In-Cab Console (`driver-dashboard.html`)
- Explain how drivers use this tablet-friendly interface.
- Demonstrate the **Passenger Counter Stepper** (`-` / `+`) updating seat occupancy percentage.
- Show the large physical touch controls for starting/pausing GPS broadcast and reporting delays.

### Step 7: Emergency Dispatch & Alternative Fleet (`emergency-management.html`)
- Demonstrate the **Automated Alternative Bus Recommendation Engine**.
- Explain the algorithm matching route overlap (95%) and capacity (50 seats) to absorb all 22 stranded students.
- Click **"Deploy Standby Bus #22 Now"** to execute relief dispatch.

---

## 🎨 Design System (Obsidian Transit)

- **Canvas Background:** `#121212` (Deep Obsidian)
- **Card Surface:** `#1E1E1E` (Charcoal Elevation)
- **Primary Accent:** `#8B5CF6` (Vibrant Purple)
- **Secondary Accent:** `#C4B5FD` (Lavender Tint)
- **Alert Colors:** Emerald `#10B981` (On-Time), Amber `#F59E0B` (Delayed), Red `#EF4444` (Breakdown)
- **Typography:** Plus Jakarta Sans & Inter
- **Icons:** Google Material Symbols Outlined

---

## 🔮 Next Step: Phase 2 Roadmap

Once frontend approval is completed:
1. **Java Backend:** Set up Java Servlets / Spring Boot REST API controllers.
2. **Database:** Design MySQL relational schema (`buses`, `routes`, `stops`, `students`, `drivers`, `telemetry_logs`).
3. **JDBC Connection:** Replace `DataStore` localStorage calls with asynchronous `fetch()` API calls to Java endpoints.
4. **WebSocket / SSE:** Connect simulated GPS streams to WebSocket channels for multi-client synchronization.
